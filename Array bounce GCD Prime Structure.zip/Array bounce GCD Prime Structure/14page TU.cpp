#include<iostream>
using namespace std;
int main()
{
int i,j;
double d;
i=10,j=20;d=99.101;

cout<<"here are some values:\t";
cout<<i;
cout<<' ';
cout<<j;
cout<<' ';

cout<<d;
return 0;
}

