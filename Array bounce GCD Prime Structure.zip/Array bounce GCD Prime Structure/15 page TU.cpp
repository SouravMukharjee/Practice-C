#include<iostream>
using namespace std;
int main()
{
	int i,j;
	double d;
	i=10,j=20;d=99.101;
cout<<"here are some values:\n";
cout<<i<<' '<<j<<' '<<d;
return 0;
}
