//*********************SHOPON(CODEHEAD)- UNIVERSITY OF ASIA PACIFIC *************************//
//*************************************UAP_BRAINBONE****************************************//
//************************************Header Files*****************************************//
#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<set>
#include<cctype>
#include<list>
using namespace std;
//************************************Macros*********************************************//
#define MAX 1000000
#define fmax(a,b) ((a>b)?a:b)
#define fmin(a,b) ((a<b)?a:b)
#define swap(x,y) int t;t=x;x=y;y=t
#define PI 3.1416
#define lp 20071027
#define pf printf
#define fr(n,a) for(int i=0;i<n;i++)
#define pb push_back
#define sc1(t) scanf("%d",&t)
#define sc2(a,b) scanf("%d%d",&a,&b)
#define sc3(a,b,c) scanf("%d%d%d",&a,&b,&c)
#define sclld(a) scanf("%lld",&a)
#define scstr(l) scanf("%[^\n]",l)
#define make(a,d) memset(a,d,sizeof(a))
//***********************************main function from here****************************//

/*
//Positive
int main()
{
    long sum=6;
    int c1=5,c2=0;
    int count=0;
    while(count!=100)
    {
        sum+=c1+c2;
        c2+=2;
        count++;
    }
    pf("%ld",sum);
    return 0;
}
*/

//Negetive
/*
int main()
{
    long sum=6;
    int c1=5,c2=0;
    int count=0;
    while(count!=100)
    {
        sum-=c1+c2;
        c2+=2;
        count++;
    }
    pf("%ld",sum);
    return 0;
}
*/
